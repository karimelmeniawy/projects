package model;

public class StateArmored extends State {

	@Override
	public void act(MainPlayer mainPlayer, double ratio) {
      mainPlayer.SetUnArmored();		
	}


	
}
