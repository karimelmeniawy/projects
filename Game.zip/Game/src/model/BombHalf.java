package model;

import java.awt.Point;

public class BombHalf extends Bombs{

	public BombHalf(Point position) {
		super(true, true, 1 ,0.5,position);
	}

	@Override
	public void act(MainPlayer player) {
	}

}
