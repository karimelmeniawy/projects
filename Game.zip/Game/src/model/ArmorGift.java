package model;

import java.awt.Point;

public class ArmorGift extends Gift {

	public ArmorGift(Point position) {
		super(position);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void act(MainPlayer player) {
		player.setPosition(this.position);
		ArmorDecorator ad=new ArmorDecorator(player);
		player.setArmored();
		ad.decorate();
		this.setVisibilty(false);
	}

}
