package model;

import java.awt.Point;

public abstract class Gift extends MazeObject{
	
	

	public Gift(Point position) {
		super(true,true,1,position);
		
		
	}


        @Override
        public abstract void act(MainPlayer player);
	// TODO Auto-generated method stub
	

}

