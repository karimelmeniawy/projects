package model;

import java.awt.Point;
import model.Wall;

public class tree extends Wall{
    
private static int dimension=1;
	public tree(Point position) {
		super(dimension, true,position);
}

public void act(MainPlayer player) {
}

 public void destroy() {
	 

 
 
 
 
 
		this.setVisibilty(false);
		this.setMoveable(true);
		
 }

}
