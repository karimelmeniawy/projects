package model;

public abstract class Decorator extends MainPlayer {
	
	public abstract void decorate();

}
