package model;

import java.awt.Point;

public abstract class MazeObject {
	protected boolean moveable;
	protected boolean takingAbility;
	protected int size;
	private boolean visibilty;
	static Point position= new Point(0,0);

	public MazeObject(boolean moveable, boolean takingAbility, int size,Point position) {
		this.moveable = moveable;
		this.takingAbility = takingAbility;
		this.size = size;
		this.position=position;
		this.setVisibilty(true);

	}

	public boolean isVisibilty() {
		return visibilty;
	}

	public void setVisibilty(boolean visibilty) {
		this.visibilty = visibilty;
	}

	public boolean isMoveable() {
		return moveable;
	}

	public void setMoveable(boolean moveable) {
		this.moveable = moveable;
	}

	public boolean isTakingAbility() {
		return takingAbility;
	}

	public void setTakingAbility(boolean takingAbility) {
		this.takingAbility = takingAbility;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

public abstract void act(MainPlayer player);
static {
	// TODO Auto-generated method stub
}	
}
	



