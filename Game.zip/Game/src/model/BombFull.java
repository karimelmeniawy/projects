package model;

import java.awt.Point;

public class BombFull extends Bombs {

	public BombFull(Point position) {
		super(true, true, 1, 1.0,position);
	}

	@Override
	public void act(MainPlayer player) {
	}
	

}
