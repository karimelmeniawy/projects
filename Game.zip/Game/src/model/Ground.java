/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.Image;
import java.awt.Point;
import javax.swing.ImageIcon;

/**
 *
 * @author wassim mahmoud
 */
public class Ground extends MazeObject{

     private ImageIcon ground ;
     
     public Ground()
     {
     super(false,false,0,null);
     }
     
     
    public Ground(boolean moveable, boolean takingAbility, int size, Point position) {
        super(moveable, takingAbility, size, position);
    }
 

    @Override
    public void act(MainPlayer player) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @return the ground
     */
    public Image getGround() {
        this.ground= new ImageIcon(this.getClass().getResource("1.png"));
        return ground.getImage();
    }
    
    
    
}
