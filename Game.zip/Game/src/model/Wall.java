package model;

import java.awt.Image;
import java.awt.Point;
import javax.swing.ImageIcon;

public abstract class Wall extends MazeObject{
    
    
    private  ImageIcon wall;
      public Image getWall() {
          this.wall = new ImageIcon(this.getClass().getResource("70.png"));
        return wall.getImage();
    }  
    
    
    
	private boolean destroyable;
public Wall()
{
super(false,false, 0,null);
}
	public Wall(int size,boolean destroyable,Point position) {
		super(false, false, size,position);
this.destroyable=destroyable;

}	

	
	
	public void act(MainPlayer player)
	{
		if(this.isMoveable()==true) {
			player.setPosition(this.position);
		}
	}

}
