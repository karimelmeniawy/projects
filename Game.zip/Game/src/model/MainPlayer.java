package model;

import java.awt.Point;

public abstract class MainPlayer {

	
	StateUnArmored StateUnArmored=new StateUnArmored();
	StateArmored StateArmored=new StateArmored();
	State CurrentState;
	private int health,ammo;
	public boolean armor;
	private Point position;
        private int Score;
	
	
	static Point A=new Point(0,0);

	public MainPlayer() {
		this.health = 100;
		this.ammo = 6;
		this.armor = false;
		this.position = A;
		this.CurrentState=StateUnArmored;
                this.Score=0;
	}
	
	
	
	
	public void setArmored() {
		this.CurrentState=StateArmored;
                armor=true;
	}
	public void SetUnArmored() {
		this.CurrentState=StateUnArmored;
                armor=false;
		
	}
	
	
	public int getHeath() {
		return health;
	}
	public void setHealth(int heath) {
		this.health = heath;
	}
	public int getAmmo() {
		return ammo;
	}
	public void setAmmo(int ammo) {
		this.ammo = ammo;
	}
	public boolean isArmor() {
		return armor;
	}
	public void setArmor(boolean armor) {
		this.armor = armor;
	}
	public Point getPosition() {
		return position;
	}
	public void setPosition(Point position) {
		this.position = position;
	}
        public void bomb(MainPlayer m,double d) {
		m.CurrentState.act(m,d);
               
		
	}

    /**
     * @return the Score
     */
    public int getScore() {
        return Score;
    }

    /**
     * @param Score the Score to set
     */
    public void setScore(int Score) {
        this.Score = Score;
    }
	
	
}
