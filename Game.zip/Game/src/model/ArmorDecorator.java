package model;


public class ArmorDecorator extends Decorator {
	
	MainPlayer player;
	
	public ArmorDecorator(MainPlayer player) {
		this.player=player;
	}
	
	public void decorate() {
		player.setArmor(true);
                
	}

}
