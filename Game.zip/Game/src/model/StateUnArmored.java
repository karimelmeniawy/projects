package model;

public class StateUnArmored extends State {
	
public void act(MainPlayer mainPlayer,double ratio) {
	
	mainPlayer.setHealth((int) (mainPlayer.getHeath()*ratio));
}



}
