package model;

import java.awt.Point;

public class AmmoGift extends Gift {

	public AmmoGift(Point position) {
		super(position);
	}

	@Override
	public void act(MainPlayer player) {
		player.setPosition(this.position);
		player.setAmmo(6);
	
	
	
	
	
		this.setVisibilty(false);
		
	}

}
