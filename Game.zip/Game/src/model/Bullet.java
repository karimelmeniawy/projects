/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import controller.MyController;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author wassim mahmoud
 */
public class Bullet {
     private ArrayList<ImageIcon> bullet = new ArrayList();

    char c;
    int x=0, y=0, speed = 10;

    public Bullet(int x, int y, char c) {
        this.x = x ;
        this.y = y;
        this.c = c;
    }

     MyController cnt = MyController.getInstance();

    public void fire(Graphics g,JLabel o) {
        switch (this.c) {
            case 'r':
                while (x < 810 && !cnt.destroy(x, y,this.c)) {
                    x += speed;
                    drawBullet(g);
                    
                }
                cnt.deletefrommaze(y, x,this.c);
  
               
                break;
            case 'l':
                while (x > 0 && !cnt.destroy(x, y,this.c)) {
                    x -= speed; 
                    
                    drawBullet(g);
                   
                }
                cnt.deletefrommaze(y, x,this.c);
                 break;
            case 'u':
                while (y > 0 && !cnt.destroy(x, y,this.c)) {
                    y -= speed;
                    drawBullet(g);
                }cnt.deletefrommaze(y, x,this.c);
            
                 
                break;
            case 'd':
                while (y < 660 && !cnt.destroy(x, y,this.c)) {
                    y += speed;
                    drawBullet(g);
                }
                
                 cnt.deletefrommaze(y, x,this.c);
               
                break;
            default:
                break;
        }
    }

    public int getX() {
        return x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    public void drawBullet(Graphics g) {
      if (getX() < 790 && getX() > 0 && getY() > 0 && getY() < 660) {
            Image j = null;
            bullet.add(new ImageIcon(this.getClass().getResource("ds.png")));//right
            bullet.add(new ImageIcon(this.getClass().getResource("s.png")));//left
            bullet.add(new ImageIcon(this.getClass().getResource("q.png")));//up
            bullet.add(new ImageIcon(this.getClass().getResource("ss.png")));//down
            switch (this.c) {
                case 'd':
                    j = bullet.get(3).getImage();
                    break;
                case 'u':
                    j = bullet.get(2).getImage();
                    break;
                case 'l':
                    j = bullet.get(1).getImage();
                    break;
                case 'r':
                    j = bullet.get(0).getImage();
                    break;
                default:
                    break;
            }

            g.drawImage(j, x, y, null);
        }}
    
    
        public Image getBullet() {
            Image j = null;
            bullet.add(new ImageIcon(this.getClass().getResource("ds.png")));//right
            bullet.add(new ImageIcon(this.getClass().getResource("s.png")));//left
            bullet.add(new ImageIcon(this.getClass().getResource("q.png")));//up
            bullet.add(new ImageIcon(this.getClass().getResource("ss.png")));//down
            switch (this.c) {
                case 'd':
                    j = bullet.get(3).getImage();
                    break;
                case 'u':
                    j = bullet.get(2).getImage();
                    break;
                case 'l':
                    j = bullet.get(1).getImage();
                    break;
                case 'r':
                    j = bullet.get(0).getImage();
                    break;
                default:
                    break;
            }

           return j;
        
    }
}
    
    
    
  