package model;

import java.awt.Point;

public abstract class Bombs extends MazeObject {

	private double damage;

	
	
public Bombs(boolean moveable, boolean takingAbility, int size, double damage,Point position) {
		super(moveable, takingAbility, size,position);
		this.damage = damage;
	}

        @Override
        public abstract void act(MainPlayer player);
static {
	// TODO Auto-generated method stub
}

}
