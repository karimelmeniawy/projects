package model;

import java.awt.Image;
import java.awt.Point;
import javax.swing.ImageIcon;
import model.Wall;

public class Stone extends Wall {
     private ImageIcon stone ;
    
    
	private static int size=1;

	public Stone(Point position) {
		super(size, false,position);
}

   

    public Stone(int size, boolean destroyable, Point position) {
        super(size, destroyable, position);
    }

    /**
     * @return the stone
     */
    public Image getStone() {
        this.stone= new ImageIcon(this.getClass().getResource("3.png"));
        return stone.getImage();
    }

	
	
	
}
