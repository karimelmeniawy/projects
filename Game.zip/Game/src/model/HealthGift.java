package model;

import java.awt.Point;

public class HealthGift extends Gift {

	public HealthGift(Point Position) {
		super(position);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void act(MainPlayer player) {
		player.setPosition(this.position);
		player.setHealth(100);
		this.setVisibilty(false);
	}

	

}
