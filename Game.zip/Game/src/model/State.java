package model;

public abstract class State {

public abstract  void act(MainPlayer mainPlayer,double ratio);

	

}
