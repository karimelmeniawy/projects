package model;

import java.awt.Point;
public class Player extends MainPlayer {

	

	private static Player uniquePlayer; 
	private Player(){  };
	
	



	public static synchronized Player getInstance()
	{
		if(uniquePlayer==null)
			uniquePlayer=new Player();
		return uniquePlayer;
	}
	

	public void bomb(double ratio) {
		this.CurrentState.act(this, ratio);
	}

}
