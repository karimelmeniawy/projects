/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author wassim mahmoud
 */
public class Character extends MainPlayer{
      private ArrayList<Bullet> bullets = new ArrayList();
     private  ArrayList<ImageIcon> character= new ArrayList();
    private  ArrayList<ImageIcon> armored_character = new ArrayList();
     
    private int x=35;
    private int y=38;
    private boolean down=true;
    private boolean up;
    private boolean left;
    private boolean right;
    public void Character()
    {
    
    }
    	private static Character uniquePlayer; 
	private Character(){  };
	
	



public static synchronized Character getInstance()
	{
		if(uniquePlayer==null)
			uniquePlayer=new Character();
               
		return uniquePlayer;
	}

    public Image getCharImage(){
        if(armor){
    this.armored_character.add(new ImageIcon(this.getClass().getResource("8.png")));
    this.armored_character.add(new ImageIcon(this.getClass().getResource("33.png")));
    this.armored_character.add(new ImageIcon(this.getClass().getResource("33r.png")));
    this.armored_character.add(new ImageIcon(this.getClass().getResource("65.png")));
  
    if( isDown())
    {
     return this.armored_character.get(0).getImage();
    }
    else if(isUp())
    { return this.armored_character.get(3).getImage();}
   else if(isLeft())
    { return this.armored_character.get(1).getImage();}
   else if(isRight())
    { return this.armored_character.get(2).getImage();}
   
   else{
   }
        return this.armored_character.get(0).getImage();
        }
        
        else{
        
             this.character.add(new ImageIcon(this.getClass().getResource("0.png")));
    this.character.add(new ImageIcon(this.getClass().getResource("39.png")));
    this.character.add(new ImageIcon(this.getClass().getResource("43r.png")));
    this.character.add(new ImageIcon(this.getClass().getResource("73.png")));
    if( isDown())
    {
     return this.character.get(0).getImage();
    }
    else if(isUp())
    { return this.character.get(3).getImage();}
   else if(isLeft())
    { return this.character.get(2).getImage();}
   else if(isRight())
    { return this.character.get(1).getImage();}
   
   else{
   }
        return null;
        }   
    }
     
    public void drawChar(Graphics g)
    {
      g.drawImage(getCharImage(), getX(), getY(), null);  
    }


    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * @param down the down to set
     */
    public void setDown(boolean down) {
        this.down = down;
        up=false;
        left=false;
        right=false;
    }

    /**
     * @param up the up to set
     */
    public void setUp(boolean up) {
        this.up = up;
       down=false;
        left=false;
        right=false;
    }

    /**
     * @param left the left to set
     */
    public void setLeft(boolean left) {
        this.left = left;
        up=false;
        down=false;
        right=false;
    }

    /**
     * @param right the right to set
     */
    public void setRight(boolean right) {
        this.right = right;
       up=false;
        left=false;
        down=false;
    }

    /**
     * @return the down
     */
    public boolean isDown() {
        return down;
    }

    /**
     * @return the up
     */
    public boolean isUp() {
        return up;
    }

    /**
     * @return the left
     */
    public boolean isLeft() {
        return left;
    }

    /**
     * @return the right
     */
    public boolean isRight() {
        return right;
    }
   
       public void shoot(Graphics g) {
        if (this.right) {
            Bullet b = new Bullet(getX(), getY(), 'r');
            bullets.add(b);

        } else if (this.down) {
            Bullet b = new Bullet(getX(), getY(), 'd');
            bullets.add(b);

        } else if (this.up) {
            Bullet b = new Bullet(getX(), getY(), 'u');
            bullets.add(b);

        } else if (this.left) {
            Bullet b = new Bullet(getX(), getY(), 'l');
            bullets.add(b);

        }

    }

    public ArrayList<Bullet> getBullets() {
        return bullets;
    }
    
     public String getState()
    {
        String state,direction=null;
        if(isRight())
            direction="right";
        else if(isDown())
            direction="down";
        else if(isUp())
            direction="up";
        else if(isLeft())
            direction="left";
        state=""+getX()+","+""+getY()+","+direction+","+""+getHeath()+","+""+getAmmo()+","+""+getScore()+","+""+isArmor();
        return state;
        
    }
    
    public void setState(String state)
    {
        String[] s = state.split(",");
        setX(Integer.parseInt(s[0]));
        setY(Integer.parseInt(s[1]));
        if("right".equals(s[2]))
            setRight(true);
        else if("down".equals(s[2]))
            setDown(true);
        else if("up".equals(s[2]))
            setUp(true);
        else if("left".equals(s[2]))
            setLeft(true);
        setHealth(Integer.parseInt(s[3]));
        setAmmo(Integer.parseInt(s[4]));
        setScore(Integer.parseInt(s[5]));
        if("true".equals(s[6]))
            setArmored();
        else 
            SetUnArmored();
    }

}
