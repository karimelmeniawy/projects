/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

/**
 *
 * @author wassim mahmoud
 */
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.*;
import java.awt.event.*;
import static java.lang.System.exit;

/**
 *
 */
public class timer extends JFrame{
 JLabel promptLabel,timerLabel;  
int counter;
JTextField tf;
JButton button;
Timer timer;
public timer(){
setLayout(new GridLayout(2,2,5,5));
    setSize(250, 150);
promptLabel=new JLabel("left time in seconds:",SwingConstants.CENTER);
add(promptLabel);

button =new JButton("start timing");
add(button);
event e= new event();
button.addActionListener(e);
timerLabel=new JLabel("playing",SwingConstants.CENTER);
add(timerLabel);

}



class event implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
 button.setVisible(false);
    int count=(int)(360);
    timerLabel.setText("Time Left: "+count);
    TimeClass tc=new TimeClass(count);
    timer=new Timer(1000,tc);
    timer.start();
           }
    

    
}
public class TimeClass implements ActionListener{
int counter;
public TimeClass(int counter){
this.counter=counter;
}


        @Override
        public void actionPerformed(ActionEvent ae) {
 
counter--;

if(counter>=1){
timerLabel.setText("time left: "+counter);}
else {
timer.stop();
timerLabel.setText("you lost");
JOptionPane.showMessageDialog(null,"Time's up , You Lost");
exit(5);
Toolkit.getDefaultToolkit().beep();
}        }


}


public static void main(String args[]){
timer gui=new timer();
gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
gui.setSize(250,100);
gui.setTitle("timerWndow");
gui.setVisible(true);
        
        }}
