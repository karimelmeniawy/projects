package controller;

import com.sun.glass.events.KeyEvent;
import com.sun.org.apache.bcel.internal.generic.GOTO;
import java.awt.Graphics;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.exit;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import model.Character;
import model.BombFull;
import model.BombHalf;
import model.ArmorGift;
import model.*;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import view.Starter;


public class MyController {
    JFileChooser chooser=new JFileChooser();
    JFrame Frame = new JFrame();
    CareTaker caretaker=new CareTaker();
    Character c = Character.getInstance();
    Point p = new Point(0, 0);
    Timer timer = new Timer();
   Mazes Maz=new Mazes();
   public int[][] maze= Maz.getMaze();

    	private static MyController uniquecontroller; 
	private MyController(){  };
	
	



public static  MyController getInstance()
	{
		if(uniquecontroller==null)
			uniquecontroller=new MyController();
               
		return uniquecontroller;
	}


    public MazeObject Create(String type, Point position) {
        MazeObject Mnew = null;
        if (type == "HealthGift") {
            Mnew = new HealthGift(position);
        }
        if (type == "AmmoGift") {
            Mnew = new AmmoGift(position);
        }
        if (type == "ArmorGift") {
            Mnew = new ArmorGift(position);
        }
        if (type == "Bombhalf") {
            Mnew = new BombHalf(position);
        }
        if (type == "BombFull") {
            Mnew = new BombFull(position);
        }
        return Mnew;

    }

    public void Active(MainPlayer player, MazeObject object) {
        if (object instanceof BombHalf) {
            player.bomb(player, 0.5);
        }
        if (object instanceof BombFull) {
            player.bomb(player, 0);
        } else {
            object.act(player);
        }
    }

    /**
     *
     * @param g
     */
    ImageIcon ground, wall, stone, healthmush, halfmush, healthgift, shield, ammorecharge;

    /**
     *
     * @param g
     */
    boolean n = true;
    int x1, y1;

    public void DrawMap(Graphics g, JLabel o) {
        ground = new ImageIcon(this.getClass().getResource("1.png"));
        stone = new ImageIcon(this.getClass().getResource("3.png"));
        wall = new ImageIcon(this.getClass().getResource("70.png"));
        healthmush = new ImageIcon(this.getClass().getResource("mushroomhealth.png"));
        halfmush = new ImageIcon(this.getClass().getResource("mushroomammo.png"));
        healthgift = new ImageIcon(this.getClass().getResource("heartgift.png"));
        shield = new ImageIcon(this.getClass().getResource("shield.png"));
        ammorecharge = new ImageIcon(this.getClass().getResource("9.png"));
      
        
        int x = 0, y = 0;
        for (int i = 0; i < 23; i++) {

            for (int j = 0; j < 27; j++) {
                if (maze[i][j] == 0) {

                    g.drawImage(ground.getImage(), x, y, null);

                    // g.drawRect(x, y,30,30);
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }

                } else if (maze[i][j] == 1) {

                    g.drawImage(stone.getImage(), x, y, null);

                    //  g.drawRect(x, y,30,30);
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                } else if (maze[i][j] == 2) {
                    g.drawImage(wall.getImage(), x, y, null);
                    //  g.drawRect(x, y,30,30);
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                } else if (maze[i][j] == 3) {
                    g.drawImage(ground.getImage(), x, y, null);
                    g.drawImage(healthmush.getImage(), x, y, null);
                    //  g.drawRect(x, y,30,30);
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                } else if (maze[i][j] == 4) {
                    g.drawImage(ground.getImage(), x, y, null);
                    g.drawImage(healthgift.getImage(), x, y, null);
                    //  g.drawRect(x, y,30,30);
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                } else if (maze[i][j] == 5) {
                    g.drawImage(ground.getImage(), x, y, null);
                    g.drawImage(ammorecharge.getImage(), x, y, null);
                    //  g.drawRect(x, y,30,30);
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                } else if (maze[i][j] == 6) {
                    g.drawImage(ground.getImage(), x, y, null);
                    g.drawImage(shield.getImage(), x, y, null);
                    //  g.drawRect(x, y,30,30);
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                } else if (maze[i][j] == 7) {
                    g.drawImage(ground.getImage(), x, y, null);
                    g.drawImage(halfmush.getImage(), x, y, null);
                    //  g.drawRect(x, y,30,30);
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                }
            }

        
        g.drawImage(c.getCharImage(), c.getX(), c.getY(), null);
        drawObserver(o);
    }
             
        
    
    }
    int x = 38, y = 38;

    public void movement(Graphics g, int key, JLabel o) {
        if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {

            movefront(g, o);

        } else if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {

            moveback(g, o);
        } else if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {

            moveleft(g, o);
        } else if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {//c.setRight(true);
            moveright(g, o);

        } else if (key == KeyEvent.VK_SPACE) {
            if (c.getAmmo() != 0) {
                c.setAmmo(c.getAmmo() - 1);

               // DrawMap(g, o);
                c.shoot(g);
                moveBullets(g, o);

            }
        } else if (key == KeyEvent.VK_PAUSE || key == KeyEvent.VK_P) {
            JOptionPane.showMessageDialog(null," Paused ");
            
        } 
        else if (key == KeyEvent.VK_L) {
            String s=null; 
        chooser.setDialogTitle("Specify a file to open"); 
        int userSelection = chooser.showOpenDialog(Frame);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
        File fileToSave = chooser.getSelectedFile();
        System.out.println("Save file to: " + fileToSave.getAbsolutePath());
             try {
                  FileReader fr = new FileReader(fileToSave.getAbsolutePath());
                  BufferedReader br = new BufferedReader(fr);
                  s=br.readLine();
                  System.out.println(s);
                  Memento m=new Memento(s);
                  restore(m);
                  
             } catch (IOException ex) {
                 Logger.getLogger(MyController.class.getName()).log(Level.SEVERE, null, ex);
             }x=c.getX();
             y=c.getY();
             DrawMap(g,o);
        } }
        else if (key == KeyEvent.VK_B)
        {
            chooser.setDialogTitle("Specify a file to save"); 
        int userSelection = chooser.showSaveDialog(Frame);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
        File fileToSave = chooser.getSelectedFile();
        System.out.println("Save as file: " + fileToSave.getAbsolutePath());
             try {
                 SaveFile(fileToSave.getAbsolutePath()+".txt");
             } catch (IOException ex) {
                 Logger.getLogger(MyController.class.getName()).log(Level.SEVERE, null, ex);
             }
             

        }
        }

    }

    public void movefront(Graphics g, JLabel o) {
        int[] direct = checkCollision();
        if (direct[1] != 1 && direct[1] != 2) {
            c.setY(y += 8);
        }
        c.setDown(true);
        p = new Point(c.getX(), c.getY());
        switch (direct[1]) {
            //full health bomb
            case 3:
                collide(p);
                BombFull A = new BombFull(p);
                Active(c, A);

                break;
            //health gift
            case 4:

                HealthGift s = new HealthGift(p);
                Active(c, s);
                collide(p);
                break;
            //ammo mushroom
            case 5:

                AmmoGift m = new AmmoGift(p);
                Active(c, m);
                collide(p);
                break;
            //shield
            case 6:

                ArmorGift e1 = new ArmorGift(p);
                Active(c, e1);
                collide(p);
                break;
            case 7:
                collide(p);
                BombHalf bf = new BombHalf(p);
                Active(c, bf);

                break;
            default:
                break;
        }
        DrawMap(g, o);
    }

    public void moveback(Graphics g, JLabel o) {
        int[] direct = checkCollision();
        if (direct[0] != 1 && direct[0] != 2) {
            c.setY(y -= 8);
        }
        c.setUp(true);
        p = new Point(c.getX(), c.getY());
        switch (direct[0]) {
            //full health bomb
            case 3:
                collide(p);
                BombFull A = new BombFull(p);
                Active(c, A);

                break;
            //health gift
            case 4:

                HealthGift s = new HealthGift(p);
                Active(c, s);
                collide(p);
                break;
            //ammo mushroom
            case 5:

                AmmoGift m = new AmmoGift(p);
                Active(c, m);
                collide(p);
                break;
            //shield
            case 6:

                ArmorGift A1 = new ArmorGift(p);
                Active(c, A1);
                collide(p);
                break;
            case 7:
                collide(p);
                BombHalf bf = new BombHalf(p);
                Active(c, bf);

                break;
            default:
                break;
        }
       
        DrawMap(g, o);
       
    }

    public void moveleft(Graphics g, JLabel o) {
        int[] direct = checkCollision();
        if (direct[2] != 1 && direct[2] != 2) {
            c.setX(x -= 8);
        }
        c.setLeft(true);
        p = new Point(c.getX(), c.getY());
        switch (direct[2]) {
            //full health bomb
            case 3:
                collide(p);
                BombFull A = new BombFull(p);
                Active(c, A);

                break;
            //health gift
            case 4:

                HealthGift s = new HealthGift(p);
                Active(c, s);
                collide(p);
                break;
            //ammo mushroom
            case 5:

                AmmoGift m = new AmmoGift(p);
                Active(c, m);
                collide(p);
                break;
            //shield
            case 6:

                ArmorGift Ag = new ArmorGift(p);
                Active(c, Ag);

                collide(p);
                break;
            case 7:
                collide(p);
                BombHalf bf = new BombHalf(p);
                Active(c, bf);

                break;
            default:
                break;
        }
        DrawMap(g, o);
    }

    public void moveright(Graphics g, JLabel o) {
        int[] direct = checkCollision();
        if (direct[3] != 1 && direct[3] != 2) {
            c.setX(x += 8);
        }
        c.setRight(true);
        p = new Point(c.getX(), c.getY());
        switch (direct[3]) {
            //full health bomb
            case 3:

                BombFull A = new BombFull(p);
                Active(c, A);
                collide(p);
                break;
            //health gift
            case 4:

                HealthGift s = new HealthGift(p);
                Active(c, s);
                collide(p);
                break;
            //ammo mushroom
            case 5:

                AmmoGift m = new AmmoGift(p);
                Active(c, m);
                collide(p);
                break;
            //shield
            case 6:

                ArmorGift af = new ArmorGift(p);
                Active(c, af);
                collide(p);
                //Bombhalf     
                break;
            case 7:

                BombHalf bf = new BombHalf(p);
                Active(c, bf);
                collide(p);
                break;
            default:
                break;
        }
       
        DrawMap(g, o);
    }

    public int collide(int X, int Y) {
        int i = (X / 30);
        int j = (Y / 30);

        return maze[j][i];
    }

    public int collide(Point p) {
        int i = (p.x / 30);
        int j = (p.y / 30);
        if (maze[j][i] != 2 && maze[j][i] != 1) {
            maze[j][i] = 0;
        }
        return maze[j][i];
    }

    public int[] checkCollision() {
        int up, down, left, right;
        left = collide(c.getX() - 8, c.getY() + (c.getCharImage().getHeight(null) / 2));
        right = collide(c.getX() + c.getCharImage().getWidth(null) + 8, c.getY() + (c.getCharImage().getHeight(null) / 2));
        up = collide(c.getX() + (c.getCharImage().getWidth(null) / 2), c.getY() - 8);
        down = collide(c.getX() + (c.getCharImage().getWidth(null) / 2), c.getY() + c.getCharImage().getHeight(null) + 8);

        int[] direct = {up, down, left, right};
        return direct;
    }

    public void drawObserver(JLabel o) {
        String mode;
        if (c.armor) {
            mode = "ON";
        } else {
            mode = "OFF";
        }
        if (c.getHeath() != 0) {
            if(c.getScore()!=40)
            o.setText("Health= " + c.getHeath() + " Ammo: " + c.getAmmo() + " Armor: " + mode +"  Score: "+c.getScore());
            else
            {
            JOptionPane.showMessageDialog(null," YOU WON :)");
            exit(5);
        
            }
        } else {
            JOptionPane.showMessageDialog(null, "You lost !!");
            exit(0);
        }
    }

    public boolean destroy(int X, int Y,char D) {
        boolean x=false;
        int i=0;
        int j=0;
       if (D=='r')
       {
         i = ((X+22) / 30);
         j = ((Y +8)/ 30);
       }
       else if (D=='l')
       {
       i = (X / 30);
       j = ((Y+8) / 30);
       }
       else if (D=='u')
       { i = ((X +8)/ 30);
        j = (Y / 30);
       }
       else if (D=='d')
       {  i = ((X +8)/ 30);
        j = ((Y +22)/ 30);
       }
        if (maze[j][i] != 0) {
            if(maze[j][i] != 1)
            {
            if(maze[j][i]==4 || maze[j][i]==6 ||maze[j][i]==5)
            {if(c.getScore()!=0)
            c.setScore(c.getScore()-5);
            }
            else if(maze[j][i]==3 ||maze[j][i]==7){
              c.setScore(c.getScore()+5);  
            }maze[j][i] = 0;
            }
            x=true;
            
        }
        //c.getBullets().remove(0);
        return x;
    }

    

    private void moveBullets(Graphics g, JLabel o) {

        for (Bullet bullet : c.getBullets()) {

            bullet.fire(g, o);

            //  DrawMap(g, o);
        }
        c.getBullets().clear();
    }
    public void deletefrommaze(int X,int Y,char D)
    {
     try{int i=0;
        int j=0;
       if (D=='r')
       {
         i = ((X+22) / 30);
         j = ((Y +8)/ 30);
       }
       else if (D=='l')
       {
       i = (X / 30);
       j = ((Y+8) / 30);
       }
       else if (D=='u')
       { i = ((X +8)/ 30);
        j = (Y / 30);
       }
       else if (D=='d')
       {  i = ((X +8)/ 30);
        j = ((Y +22)/ 30);
       }
        if (maze[j][i] != 0) {
            if(maze[j][i] != 1)
            {maze[j][i] = 0;
            
            }
           
            
        }}catch(Exception e)
        {}
    }
    
     public String getMaze()
    {
        String m ="";
        int k=0;
       // m = String.valueOf(maze[0][0])+",";
        int i,j;
        for(i=0;i<23;i++){
            for(j=0;j<27;j++)
            {  m=m+""+maze[i][j]+",";
            k++;}
            }
       // System.out.println(k);
        return m;
    }
    
    
    public void setMaze(String m)
    {
        //System.out.println(m);
        String[] objects=m.split(",");
       // System.out.println(objects.length);
        int i,j,x=0;
        for(i=0;i<23;i++)
        {
            for (j=0;j<27;j++)
            {
                this.maze[i][j]=Integer.parseInt(objects[x]);
                x++;
                
            }
        }
    }
    
    public Memento Save()
    {
        String s = c.getState()+"/"+getMaze();
        //System.out.println(s);
        
        return new Memento(s);
    }
    
    public void restore(Memento m)
    {
        String[] s= m.getState().split("/");
        c.setState(s[0]);
        setMaze(s[1]);
    }
    
    public void SaveFile(String path) throws IOException
    {
        caretaker.addMemento(Save());
        FileWriter fw=null;
        fw = new FileWriter(path);
        PrintWriter pw=new PrintWriter(fw);
        pw.print(caretaker.getMemento().getState());
        pw.close();
        
    }
    
    
}
