/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.Graphics;
import java.awt.Shape;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import view.GameView;
import model.Character;

/**
 *
 * @author wassim mahmoud
 */
public class Backgroung extends JPanel{
  /*  JPanel k=new JPanel();
  ArrayList<Shape> walls= new ArrayList();
   ArrayList<Shape> Stones= new ArrayList();
    ArrayList<Shape> grounds= new ArrayList();
    public void setPanel(JPanel panel){
        k=panel;
        
    }
   Character c = new Character();
     
        private int[][] maze
            = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1},
            {1, 0, 2, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1},
            {1, 0, 2, 0, 1, 1, 1, 0, 1, 0, 2, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1},
            {1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 2, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 0, 0, 2, 0, 0, 0, 2, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 2, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 2, 0, 1, 0, 1, 1},
            {1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1},
            {1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1},
            {1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 1, 1, 0, 2, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 1, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 1, 1, 0, 2, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 0, 0, 2, 2, 2, 0, 2, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
            };
  ImageIcon ground, wall,stone,charcter;
     
    /**
     *
     * @param g
     */
   
  /*  public void DrawMap(Graphics g) {
         ground = new ImageIcon(this.getClass().getResource("1.png"));
        stone = new ImageIcon(this.getClass().getResource("3.png"));
     charcter = new ImageIcon(this.getClass().getResource("0.png"));
        wall = new ImageIcon(this.getClass().getResource("70.png"));
        int x = 0, y =0;
        for (int i = 0; i < 23; i++) {

            for (int j = 0; j < 27; j++) {
                if (maze[i][j] == 0)
                {
                
                  g.drawImage(ground.getImage(), x, y,null);
                    
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }

                } else if (maze[i][j] == 1) {
               
                    g.drawImage(stone.getImage(), x, y,null);
                
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                }
                   else if (maze[i][j] == 2) {
                   g.drawImage(wall.getImage(), x, y,null);
                
                    x += 30;
                    if (x % 810 == 0) {
                        y += 30;
                        x = 0;
                    }
                }
            }

        }
      g.drawImage(charcter.getImage(),c.getX(),c.getY(), null);
    }
    int x=38,y=38;
    public void movefront(Graphics g)
    {charcter = new ImageIcon(this.getClass().getResource("0.png"));
    c.setY(y+=6);
        DrawMap(g);
        //g.drawImage(charcter.getImage(),x,y+=4,null);
    }
     public void moveback(Graphics g)
    {charcter = new ImageIcon(this.getClass().getResource("0.png"));
    c.setY(y-=6);
        DrawMap(g);
       // g.drawImage(charcter.getImage(),x,y-=4,null);
    }
      public void moveleft(Graphics g)
    {charcter = new ImageIcon(this.getClass().getResource("0.png"));
    c.setX(x-=6);
        DrawMap(g);
        //g.drawImage(charcter.getImage(),x-=4,y,null);
    }
       public void moveright(Graphics g)
    {charcter = new ImageIcon(this.getClass().getResource("0.png"));
    c.setX(x+=6);
        DrawMap(g);
        //g.drawImage(charcter.getImage(),x+=4,y,null);
    }
    
 */   
}
 