package busstation;


public class manger extends Person {

    protected long salary;

    public manger(String userName, String passWord, String name, String age) {
        super(userName, passWord, name, age);
        

    }

    
}
